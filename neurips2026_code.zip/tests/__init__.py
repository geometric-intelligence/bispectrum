"""Tests for bispectrum."""
